package util;

import android.support.v4.content.FileProvider;

/**
 * Created by Lenovo on 22-10-2017.
 */

public class GenericFileProvider  extends FileProvider {
}
