package util;

/**
 * Created by subhashsanghani on 9/29/16.
 */
public class NameValuePair {
    public String name, value;

    public NameValuePair(String _name, String _value) {
        name = _name;
        value = _value;
    }
}